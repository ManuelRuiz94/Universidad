(function() {
    const btnEliminacion = document.querySelectorAll(".btnEliminacion");

    btnEliminacion.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const confirmacion = confirm('¿Estás seguro de eliminar este dato?');
            if (!confirmacion) {
                e.preventDefault();
            }
        });
    });

    // Desvanecer alertas automáticamente
    const alertas = document.querySelectorAll('.alert');
    alertas.forEach(alerta => {
        setTimeout(() => {
            alerta.classList.remove('show');
            alerta.classList.add('fade');
            setTimeout(() => {
                alerta.remove(); // Eliminar del DOM
            }, 500); // Tiempo de desvanecimiento
        }, 3000); // Tiempo antes de desvanecer (3 segundos)
    });
})();