document.addEventListener('DOMContentLoaded', () => {
    console.log("El archivo JavaScript se ha cargado correctamente.");
    const cedulaField = document.getElementById('cedula');
    const placaField = document.getElementById('placa');

    async function checkDuplicate(field, value) {
        const response = await fetch(`/check-duplicate/?field=${field}&value=${value}`);
        const result = await response.json();
        return result.exists;
    }

    cedulaField.addEventListener('blur', async () => {
        const cedula = cedulaField.value;
        if (cedula) {
            console.log("Verificando duplicado de cédula:", cedula);
            const exists = await checkDuplicate('cedula', cedula);
            console.log("Resultado de duplicado de cédula:", exists);
            if (exists) {
                alert('Ya existe un usuario con esta cédula.');
                cedulaField.focus();
            }
        }
    });

    placaField.addEventListener('blur', async () => {
        const placa = placaField.value;
        if (placa) {
            const exists = await checkDuplicate('placa', placa);
            if (exists) {
                alert('Ya existe un vehículo con esta placa.');
                placaField.focus();
            }
        }
    });
});