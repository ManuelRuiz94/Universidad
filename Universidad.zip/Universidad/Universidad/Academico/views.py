from django.shortcuts import render, redirect,  get_object_or_404
from . models import Vehiculo, SOAT, RTM, Usuario
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import JsonResponse

#login users
from django.contrib.auth.views import LoginView
from django.urls import reverse_lazy

# Create your views here.

#vistas de los usuarios

#autenticacion de usuarios
class CustomLoginView(LoginView):
    template_name = 'Academico/login.html'
    
    def get_success_url(self):
        # Redirigir a 'gestionCursos.html' si es un superusuario
        if self.request.user.is_superuser:
            return reverse_lazy('gestion_Vehiculo')  # Redirigir al admin a la vista gestionCursos
        else:
            return reverse_lazy('Academico/login.html')  # Redirigir a la vista de usuario normal


#listar cursos
@login_required
def gestion_Vehiculo(request):
    VehiculoListados = Vehiculo.objects.all()
    messages.success(request, '¡Ingreso de informacion!')
    return render(request, 'Academico/gestionVehiculo.html', {"Vehiculo": VehiculoListados})


# Vista para el ingreso de Vehiculos
def ingreso_Vehiculo(request):
    if request.method == 'POST':
        # Captura de información del usuario
        cedula = request.POST.get('cedula')
        nombre_usuario = request.POST.get('nombre_usuario')
        correo = request.POST.get('correo')
        
        # Captura de información del vehículo
        placa = request.POST.get('placa')
        cilindraje_moto = request.POST.get('cilindraje_moto')
        marca = request.POST.get('marca')
        modelo_moto = request.POST.get('modelo_moto')
        
        # Validación de duplicados
        if Usuario.objects.filter(cedula=cedula).exists():
            messages.error(request, "Ya existe un usuario con esta cédula.")
            return render(request, 'Academico/ingresoVehiculo.html', {'cedula_duplicada': True})
        
        if Vehiculo.objects.filter(placa=placa).exists():
            messages.error(request, "Ya existe un vehículo con esta placa.")
            return render(request, 'Academico/ingresoVehiculo.html', {'placa_duplicada': True})

        # Si ambas validaciones pasan, crear el usuario y el vehículo
        usuario, created = Usuario.objects.get_or_create(
            cedula=cedula,
            defaults={'nombre_usuario': nombre_usuario, 'correo': correo}
        )

        # Guardar la información del vehículo, asociándolo al usuario
        vehiculo = Vehiculo(
            placa=placa,
            cilindraje_moto=cilindraje_moto,
            marca=marca,
            modelo_moto=modelo_moto,
            usuario=usuario  # Asigna el usuario aquí
        )
        vehiculo.save()

        # Captura y guardado de la información del SOAT
        numero_poliza = request.POST.get('numero_poliza')
        fecha_expedicion = request.POST.get('fecha_expedicion')
        fecha_vencimiento = request.POST.get('fecha_vencimiento')
        entidad_emisora = request.POST.get('entidad_emisora')

        soat = SOAT(
            numero_poliza=numero_poliza,
            fecha_expedicion=fecha_expedicion,
            fecha_vencimiento=fecha_vencimiento,
            entidad_emisora=entidad_emisora,
            vehiculo=vehiculo
        )
        soat.save()

        # Captura y guardado de la información del RTM
        numero_certificado = request.POST.get('numero_certificado')
        fecha_expedicion_rtm = request.POST.get('fecha_expedicion')
        fecha_vencimiento_rtm = request.POST.get('fecha_vencimiento')
        centro_diagnostico = request.POST.get('centro_diagnostico')

        rtm = RTM(
            numero_certificado=numero_certificado,
            fecha_expedicion=fecha_expedicion_rtm,
            fecha_vencimiento=fecha_vencimiento_rtm,
            centro_diagnostico=centro_diagnostico,
            vehiculo=vehiculo
        )
        rtm.save()

        # Mensaje de éxito y redirección
        messages.success(request, 'La información se ha guardado correctamente!')
        return redirect('gestion_Vehiculo')
    else:
        return render(request, 'Academico/ingresoVehiculo.html')




#eliminar cursos
def eliminarVehiculo(request, placa):
    vehiculo = get_object_or_404(Vehiculo, placa=placa)
    usuario = vehiculo.usuario  # Obtén el usuario relacionado con el vehículo
    
    if request.method == 'POST':
        with transaction.atomic():
            # Elimina el vehículo
            vehiculo.delete()
            
            # Verifica si el usuario no tiene otros vehículos asociados
            if not Vehiculo.objects.filter(usuario=usuario).exists():
                usuario.delete()  # Elimina el usuario si no tiene más vehículos
            
            messages.success(request, 'Registro eliminado exitosamente!')
        return redirect('gestion_Vehiculo')
    
    return render(request, 'Academico/confirmar_eliminacion.html', {'vehiculo': vehiculo})


# Editar Vehículo
def editarVehiculo(request, placa):
    vehiculo = get_object_or_404(Vehiculo, placa=placa)
    
    # Intenta obtener el SOAT y RTM, si no existen, crea instancias en blanco
    soat = SOAT.objects.filter(vehiculo=vehiculo).first() or SOAT(vehiculo=vehiculo)
    rtm = RTM.objects.filter(vehiculo=vehiculo).first() or RTM(vehiculo=vehiculo)

    if request.method == 'POST':
        # Actualizar datos de Vehículo
        vehiculo.cilindraje_moto = request.POST.get('cilindraje_moto')
        vehiculo.marca = request.POST.get('marca')
        vehiculo.modelo_moto = request.POST.get('modelo_moto')
        vehiculo.save()

        # Actualizar datos de SOAT
        soat.numero_poliza = request.POST.get('numero_poliza')
        soat.fecha_expedicion = request.POST.get('fecha_expedicion_soat')
        soat.fecha_vencimiento = request.POST.get('fecha_vencimiento_soat')
        soat.entidad_emisora = request.POST.get('entidad_emisora')
        soat.save()

        # Actualizar datos de RTM
        rtm.numero_certificado = request.POST.get('numero_certificado')
        rtm.fecha_expedicion = request.POST.get('fecha_expedicion_rtm')
        rtm.fecha_vencimiento = request.POST.get('fecha_vencimiento_rtm')
        rtm.centro_diagnostico = request.POST.get('centro_diagnostico')
        rtm.save()

        # Mensaje de éxito y redirección
        messages.success(request, 'Registro editado exitosamente!')
        return redirect('gestion_Vehiculo')

    return render(request, 'Academico/editarVehiculo.html', {
        'vehiculo': vehiculo,
        'soat': soat,
        'rtm': rtm
    })


#vista que nos tare un Json desde la BD con la verificacion de la placa y la cedula
def check_duplicate(request):
    field = request.GET.get('field')
    value = request.GET.get('value')
    exists = False

    # Validar campo y valor
    if field == 'cedula':
        exists = Usuario.objects.filter(cedula=value).exists()
    elif field == 'placa':
        exists = Vehiculo.objects.filter(placa=value).exists()

    return JsonResponse({'exists': exists})