from django.contrib import admin
from .models import Vehiculo, SOAT, RTM, Usuario

# Register your models here.
admin.site.register(Vehiculo)
# Registrar el modelo SOAT en el admin
admin.site.register(SOAT)
# Registrar el modelo RTM en el admin
admin.site.register(RTM)
# registrar el modelo usuario en el admin
admin.site.register(Usuario)