from django.urls import path
from .views import gestion_Vehiculo, editarVehiculo, eliminarVehiculo,ingreso_Vehiculo
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
     # Ruta para el login
    path('login/', auth_views.LoginView.as_view(template_name='Academico/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='/login/'), name='logout'),
    path('gestion-Vehiculo/', gestion_Vehiculo, name='gestion_Vehiculo'),
    path('ingreso-vehiculo/', ingreso_Vehiculo, name='ingreso_Vehiculo'),
    path('edicionVehiculo/<str:placa>/', editarVehiculo, name='editar_Vehiculo'),
    path('eliminacionVehiculo/<str:placa>/', eliminarVehiculo, name='eliminar_Vehiculo'),
    path('check-duplicate/', views.check_duplicate, name='check_duplicate'),
]