from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

# Tabla de usuarios (principal)
class Usuario(models.Model):
    cedula = models.CharField(max_length=20, primary_key=True)  # Nueva llave primaria cédula
    nombre_usuario = models.CharField(max_length=50, unique=True)  # Nombre único para cada usuario
    correo = models.EmailField(unique=True)  # Correo único para cada usuario

    def __str__(self):
        return self.nombre_usuario

# Tabla de vehículos, que antes se llamaba Curso
class Vehiculo(models.Model):
    placa = models.CharField(primary_key=True, max_length=6)  # Placa del vehículo
    cilindraje_moto = models.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(9999)], default=1)  # Cilindraje de la moto
    marca = models.CharField(max_length=10)  # Marca del vehículo
    modelo_moto = models.CharField(max_length=4)  # Modelo del vehículo
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, to_field='cedula')  # Relación con Usuario, usando la cédula

    def __str__(self):
        return f"{self.marca} {self.placa} ({self.cilindraje_moto})"

# Tabla del SOAT, relacionada con Vehiculo
class SOAT(models.Model):
    numero_poliza = models.CharField(max_length=20)
    fecha_expedicion = models.DateField()
    fecha_vencimiento = models.DateField()
    entidad_emisora = models.CharField(max_length=100)
    vehiculo = models.ForeignKey(Vehiculo, on_delete=models.CASCADE)  # Relación con Vehiculo

    def __str__(self):
        return f"SOAT {self.numero_poliza} - {self.entidad_emisora}"

# Tabla de la RTM, relacionada con Vehiculo
class RTM(models.Model):
    numero_certificado = models.CharField(max_length=20)
    fecha_expedicion = models.DateField()
    fecha_vencimiento = models.DateField()
    centro_diagnostico = models.CharField(max_length=100)
    vehiculo = models.ForeignKey(Vehiculo, on_delete=models.CASCADE)  # Relación con Vehiculo

    def __str__(self):
        return f"RTM {self.numero_certificado} - {self.centro_diagnostico}"
